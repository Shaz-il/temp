import socket
import json
from cryptography.fernet import Fernet
import sys
import os

# Load the encryption key from file
def load_key():
    with open('encryption_key.key', 'rb') as key_file:
        key = key_file.read()
    return key

def decrypt_message(encrypted_message, key):
    f = Fernet(key)
    decrypted_message = f.decrypt(encrypted_message)
    return decrypted_message.decode()

def main():
    # Check if the application is being run directly
    if 'LAUNCHER_AUTHORIZED' not in os.environ:
        print("Error: Unauthorized access. Please use the launcher to start the application.")
        sys.exit(1)

    # Define server parameters
    HOST = 'localhost'
    PORT = 12345

    # Load encryption key
    key = load_key()

    # Start server to listen for launcher.py connection
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()

        while True:
            conn, addr = s.accept()
            encrypted_token = conn.recv(1024)

            # Decrypt token received from launcher.py
            decrypted_token = decrypt_message(encrypted_token, key)

            # Replace 'EXPECTED_TOKEN' with your actual verification token
            expected_token = 'YOUR_VERIFICATION_TOKEN'

            if decrypted_token == expected_token:
                # Replace with your application version
                app_version = '1.0'  # Change to your actual application version

                # Send back response with version info
                response_message = f"OK|{app_version}"
                conn.sendall(response_message.encode())
                print("Welcome! Application launched successfully.")
                break
            else:
                conn.sendall(b'ERROR')
                print("Unauthorized access attempt. Closing connection.")
                conn.close()

if __name__ == '__main__':
    main()
